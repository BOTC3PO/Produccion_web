<?php 
#define("BASE_URL","http://localhost/PHP/Final/");
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'mydb');
define('DB_USER','root');
define('DB_PASSWORD','');

define("PathList",[
    "index.php",
    "producto.php",
    "perfil.php",
    "login.php",
    "carrito.php",
    "contacto.php",
    "catalogo.php",
    "recomendaciones.php"
])
?>
