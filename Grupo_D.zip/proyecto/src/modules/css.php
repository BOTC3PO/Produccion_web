
  <link href="src/css/style.css" rel="stylesheet" />
  <link rel="stylesheet" href="src/css/extras.css"/>
 <!-- <link rel="stylesheet" href="node_modules/izitoast/dist/css/iziToast.min.css" />
  <link rel="stylesheet" href="node_modules/alertifyjs/build/css/alertify.min.css" />
  <link rel="stylesheet" href="node_modules/alertifyjs/build/css/themes/default.rtl.min.css" />-->
  </head>