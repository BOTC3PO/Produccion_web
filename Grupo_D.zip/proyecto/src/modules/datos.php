<?php
$dir_marca='http://localhost/proyecto/src/productos/marcas/';
$marcas = ['western-digital','seagate','thermaltake','thermaltake','cooler-master','null','nvidia','msi','aorus','asus-rog','amd','amd','corsair','kingston','kingston','western-digital'];
$dir_producto='http://localhost/proyecto/src/productos/productos/';
$producto = ['disco1','disco2','fuente1','fuente2','gabinete1','gabinete2','grafica1','grafica2','mother1','mother2','procesador1','procesador2','ram1','ram2','ssd1','ssd2'];
$titulo = ['disco duro hdd 1tb','disco duro seagate 2tb','fuente de poder 600w','fuente de poder 1200w','gabinete cooler master','gabinete gamemax','nvidia rtx 2060','radeon rx 6800xt','motherboard x570 aorus','motherboard b550 rog strix','amd ryzen 5 5600x','AMD RYZEN 7 5700G','memoria ram ddr4 corsair venance rgb pro','memoria ram ddr4 fury beast','ssd kingston 240 gb','ssd mvme wd green 240 gb'];
#$descripcion = [''];
$precio = [25800,34600,30500,86677,42400,35614,195000,553649,237255,113740,180869,200500,69090,32120,21999,13220];

?>