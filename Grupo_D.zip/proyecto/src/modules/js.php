
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <!--<script src="node_modules/animejs/lib/anime.min.js"></script>-->
  <!--alertas cliente
  <script src="node_modules/izitoast/dist/js/iziToast.min.js"></script>-->
  <!--alertas mod
  <script src="node_modules/alertifyjs/build/alertify.min.js"></script>-->
  <!--alertas borrar
  <script src="node_modules/sweetalert2/dist/sweetalert2.min.js"></script>-->
  <script src="src/js/main.js"></script>
  <script src="module.js"></script>
 <!-- <script src="node_modules/parallax-js/src/parallax.js"></script>-->
 
