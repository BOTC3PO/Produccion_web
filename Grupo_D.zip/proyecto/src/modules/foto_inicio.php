<div class="flex justify-center flex-col items-center">
    <h1 class="text-4xl"></h1>
    <img src="src/interface/banner1.png" alt="" class="w-auto h-auto bg-cover " />
</div>
