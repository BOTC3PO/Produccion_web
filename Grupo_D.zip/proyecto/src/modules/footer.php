<footer class="bg-gray-700 w-full max-h-50 min-h-50 h-screen2">
    <div class="flex w-full h-5/6 justify-center align-middle items-center">
    <p class="font-icons text-6xl m-6">k</p>
    <p class="font-icons text-6xl m-6">R</p>
    <p class="font-icons text-6xl m-6">E</p>
    <p class="font-icons text-6xl m-6">Q</p>
    </div>
  <div class="text-center">
  <p>copyright 2023 marca </p>
  </div>
  </footer>

